<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuarantineAreaType extends Model
{
    //
    protected $fillable = [
        'name'
    ];
}
