<a href="{{route('block_persons.check',['id'=>$id,'type'=>'runAway'])}}" class="btn btn-primary"> <i
        class="fa fa-users"></i> </a>
