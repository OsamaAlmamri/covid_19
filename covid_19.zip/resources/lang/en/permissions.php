<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Shop Language Lines
    |--------------------------------------------------------------------------
    */

    'updateExtraPermissionsFor'=>'Update Extra Permissions For ',

    'permissions' => [
        'permissions' => 'permissions',
        'AllPermissions' => ' All Permissions',
        'edit' => ' edit',
        'extraPermissions' => ' Extra Permissions',
    ],
    'role' => [
        'role' => ' role',
        'new' => ' new role',
        'update' => ' update role',
        'name' => 'role  name',
        'selectAll' => ' selectAll ',
        'selectAllFor' => ' select All For',

    ],

];
