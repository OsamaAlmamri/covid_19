<a href="{{route('users.permissions', $id)}}" class="btn btn-info"> <i class="fa fa-user-secret"></i> </a>

