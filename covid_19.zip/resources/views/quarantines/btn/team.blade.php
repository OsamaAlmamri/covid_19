<a href="{{route('check_points.team',['id'=>$id,'type'=>'health_teams'])}}" class="btn btn-primary"> <i
        class="fa fa-users"></i> </a>
